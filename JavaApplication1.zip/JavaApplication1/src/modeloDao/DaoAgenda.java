/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloDao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modeloBeans.BeansAgenda;
import modeloConection.ConexaoBD;

/**
 *
 * @author Juliana
 */
public class DaoAgenda {
    
    BeansAgenda agenda = new BeansAgenda();
    ConexaoBD conex = new ConexaoBD();
    ConexaoBD conexPaciente = new ConexaoBD();
    ConexaoBD conexMedico = new ConexaoBD();
    int codMed;
    int codPac;
    
    public void Salvar(BeansAgenda agenda){
        BuscaMedico(agenda.getNomeMedico());
        BuscaPaciente(agenda.getNomePac());
        conex.conexao();
        
        try {
            PreparedStatement pst =conex.conn.prepareStatement("insert into agenda(agenda_codpac, agenda_codmedico, agenda_motivo, agenda_turno, agenda_data, agenda_status) values(?,?,?,?,?,?)");
            pst.setInt(1, codPac);
            pst.setInt(2, codMed);
            pst.setString(3, agenda.getMotivo());
            pst.setString(4,agenda.getTurno());
            pst.setDate(5, new java.sql.Date(agenda.getData().getTime()));
            pst.setString(6,agenda.getStatus());
            pst.execute();
            JOptionPane.showMessageDialog(null,"Agendamento  marcado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao salvar agendament"+ex);
        }
        conex.desconecta();
    }
    
    public void BuscaMedico(String nomeMedico){
        conexMedico.conexao();
        conexMedico.executaSql("select *from medicos where nome_medico='"+nomeMedico+"'");
        
        try {
            conexMedico.rs.first();
            codMed=conexMedico.rs.getInt("cod_medico1");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Médico não cadastrado");
        }
        
    }
    
    public void BuscaPaciente(String nomePaciente){
    
        conexPaciente.conexao();
        conexPaciente.executaSql("select *from pacientes where paci_nome='"+nomePaciente+"'");
        
        try {
            conexPaciente.rs.first();
            codPac=conexPaciente.rs.getInt("paci_codigo");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Paciente não cadastrado");
    }
    }
}
